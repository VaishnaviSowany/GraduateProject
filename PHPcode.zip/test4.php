<?php
$url = "http://google.com";
if (filter_var($url, FILTER_VALIDATE_URL)) {
  echo "URL is valid";
}
else {
  echo "URL is invalid";
}
?>