<?php
$html='<!DOCTYPE html><html><body><h1>My First Heading</h1><p>My first paragraph.</p></body></html>';

$dom = new DOMDocument;
$dom->loadHTML($html);
$allElements = $dom->getElementsByTagName('*');
echo $allElements->length;
$elementDistribution = array();
foreach($allElements as $element) {
    if(array_key_exists($element->tagName, $elementDistribution)) {
        $elementDistribution[$element->tagName] += 1;
    } else {
        $elementDistribution[$element->tagName] = 1;
    }
}
print_r($elementDistribution);
?>