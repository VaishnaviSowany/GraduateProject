<?php
include('simple_html_dom.php');
//$input = '<img src="/image/fluffybunny.jpg" title="Harvey the bunny" alt="a cute little fluffy bunny"/>';

//$page = file_get_contents($input);

//$newDom = new DOMDocument();
//@$newDom->loadHTML($page);

//$tag = $newDom->getElementsByTagName('img');

//foreach ($tag as $tag1) {
       //echo $tag1->getAttribute('src');
//};

$doc = new DOMDocument();
$doc->loadHTMLFile("weflk.html");
echo $doc->saveHTML();
?>
