<?php
include('simple_html_dom.php');
$linktopage = "http://www.pace.edu";
$sourcecode = file_get_contents( $linktopage );
$html_encoded = htmlentities($sourcecode);
echo $html_encoded;
?>