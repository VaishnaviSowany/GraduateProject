<?php
$marks=845;
$calculate = $marks;

if ($calculate < 800) {
    echo "C";
} else if ($calculate < 1200) {
    echo "B!";
} else if ($calculate == 1200) {
    echo "A";
}
?>
