<?php
include('simple_html_dom.php');

   $url="https://www.google.com/";
   $sourcecode = file_get_contents( $url);
   $html_encoded = htmlentities($sourcecode);
   libxml_use_internal_errors(true);
   $dom = new DOMDocument;
   $dom->loadHTMLFile($url);
   $tags = $dom->getElementsByTagName('*');
   echo "Total Tags : ". $tags->length . "<br /><br />";
  
   $count_tag = array();
   foreach($tags as $tag) {
    if(array_key_exists($tag->tagName, $count_tag)) {
     $count_tag[$tag->tagName] += 1;
    } else {
     $count_tag[$tag->tagName] = 1;
    }
   }
   echo "<pre>";
   print_r($count_tag);
   echo "</pre>";
   function checkHTML($html_encoded,$htmlTag){
      $openTags = preg_match('/<'.$htmlTag.'\b[^>]*>/',$html_encoded);
      $closeTags = preg_match('/<\/'.$htmlTag.'>/',$html_encoded);
      return array($openTags, $closeTags);
      }
  $numberOfParagraphTags = checkHTML($html_encoded,'a');
  echo('Open Tags:'.$numberOfParagraphTags[0].' Close Tags:'.$numberOfParagraphTags[1]);

   ?>
